import folium
import pandas

# define variable
#map=folium.Map(location=[38, 120], zoom_start=6, tiles="Stamen Terrain")

#import the data from the text file
data=pandas.read_csv("Volcanoes.txt")
lat=list(data["LAT"])
lon=list(data["LON"])
elev=list(data["ELEV"])

#use html to stylized the popup window
#="""<h4>Volcano Information:</h4>
#Height:%s m
#"""
map=folium.Map(location=[38.58, -99.09], zoom_start=6, tiles="Stamen Terrain")
#new design
#map=folium.Map(location=[38.58, -99.09], zoom_start=6, tiles="Mapbo")

#feature group
fg=folium.FeatureGroup(name="May Map")

#loop
#zip function can print the first element of array one match the second array of element one
for Lt, Ln, el in zip(lat, lon, elev):
    fg.add_child(folium.Marker(location=[Lt, Ln], popup=el, icon=folium.Icon(color="green")))   
     

map.add_child(fg)
map.save("C.html")